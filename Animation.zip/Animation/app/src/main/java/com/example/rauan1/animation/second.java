package com.example.rauan1.animation;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class second extends AppCompatActivity {
    Animation bounce,zoomin,zoomout,goleft,goright,fade,bounce1;
    String i;
    TextView t,t1;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        i = "android";
        super.onCreate(savedInstanceState);
        setContentView(R.layout.secondact);
        t = findViewById(R.id.textView2);
        t1 = findViewById(R.id.that);
        final ImageView android = findViewById(R.id.android);
        final ImageView ios = findViewById(R.id.ios);
        bounce = AnimationUtils.loadAnimation(this,R.anim.bounce);
        bounce1 = AnimationUtils.loadAnimation(this,R.anim.bounce);
        android.startAnimation(bounce);
        ios.startAnimation(bounce);
        zoomin = AnimationUtils.loadAnimation(this,R.anim.zoomin);
        zoomout = AnimationUtils.loadAnimation(this,R.anim.zoomout);
        goleft = AnimationUtils.loadAnimation(this,R.anim.goleft);
        fade = AnimationUtils.loadAnimation(this,R.anim.faded);
        goright = AnimationUtils.loadAnimation(this,R.anim.goright);
        zoomin.setStartOffset(1000);
        zoomout.setStartOffset(1000);
        goright.setFillAfter(true);
        goleft.setFillAfter(true);
        bounce.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                android.startAnimation(zoomin);
                t.setText("android");
                t.startAnimation(fade);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        zoomin.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (i.equals("android")){
                    i = "ios";
                    android.startAnimation(zoomout);
                    System.out.println("test1");
                }
                else if (i.equals("ios")){
                    i="";
                    ios.startAnimation(zoomout);
                    System.out.println("test2");
                }

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        zoomout.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (i.equals("android")){
                    android.startAnimation(zoomin);
                    System.out.println("test11");
                }
                else if (i.equals("ios")){
                    ios.startAnimation(zoomin);
                    System.out.println("test22");
                    t.setText("ios");
                    t.startAnimation(fade);
                }
                else{
                    android.startAnimation(goright);
                    ios.startAnimation(goleft);
                    bounce1.setStartOffset(2000);
                    t1.startAnimation(bounce1);
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
}
