package com.example.rauan1.animation;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    ImageView imageView;
    Animation zoomin,zoomout;
    int i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.firstanim);
        textView = findViewById(R.id.homework6);
        Animation wheelanim = AnimationUtils.loadAnimation(this,R.anim.wheelanim);
        imageView.startAnimation(wheelanim);
        Animation wordsanim = AnimationUtils.loadAnimation(this,R.anim.wordsanim);
        textView.startAnimation(wordsanim);
        zoomin = AnimationUtils.loadAnimation(this, R.anim.zoomin);
        final Intent intent = new Intent(this, second.class);
        zoomout = AnimationUtils.loadAnimation(this, R.anim.zoomout);
        textView.setAnimation(zoomin);
        i = 0;
        zoomin.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation arg0) {

            }

            @Override
            public void onAnimationRepeat(Animation arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAnimationEnd(Animation arg0) {
                if (i<=6){
                textView.startAnimation(zoomout);
                i++;
                }
                else {
                    startActivity(intent);

                }

            }
        });
        zoomout.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation arg0) {

            }

            @Override
            public void onAnimationRepeat(Animation arg0) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAnimationEnd(Animation arg0) {
                if (i<=6){
                    textView.startAnimation(zoomin);
                    i++;
                }
                else {

                    startActivity(intent);
                }

            }
        });
    }
}
