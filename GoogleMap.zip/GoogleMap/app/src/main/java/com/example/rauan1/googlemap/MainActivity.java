package com.example.rauan1.googlemap;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {
    ArrayList<Places> places = new ArrayList<>();
    private GoogleMap map;
    ListView lv;
    MyAdapter adapter;
    RelativeLayout relativeLayout;
    RadioGroup r;
    Animation zoomin,faded;
    int i = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SupportMapFragment mapFragment = (SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        relativeLayout = findViewById(R.id.rel_fragment);
        r = findViewById(R.id.radio);
        zoomin = AnimationUtils.loadAnimation(this,R.anim.zoomin);
        faded = AnimationUtils.loadAnimation(this,R.anim.faded);
        DatabaseHelper db = new DatabaseHelper(this);
        lv = findViewById(R.id.place_item);
        lv.setVisibility(View.GONE);
        places = db.getNotes();
        adapter = new MyAdapter(this,places);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                lv.setVisibility(View.GONE);
                relativeLayout.setVisibility(View.VISIBLE);
                r.setVisibility(View.VISIBLE);
                i++;
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(places.get(position).getLatlng(),map.getMinZoomLevel()));
            }
        });
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        for (int j = 0; j < places.size(); j++) {
            LatLng loc = places.get(j).getLatlng();
            map.addMarker(new MarkerOptions().position(loc).title(places.get(j).getName2()));
        }
        try{
        map.moveCamera(CameraUpdateFactory.newLatLng(places.get(places.size()-1).getLatlng()));}
        catch (ArrayIndexOutOfBoundsException e){

        }
        map.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(final LatLng latLng) {
                final AlertDialog.Builder mBuilder = new AlertDialog.Builder(MainActivity.this);
                @SuppressLint("ViewHolder") View view1 = LayoutInflater.from(getApplicationContext()).inflate(R.layout.inf_note,null);
                Button bty = view1.findViewById(R.id.ok);
                Button btn = view1.findViewById(R.id.cancel);
                final EditText name1 = view1.findViewById(R.id.location);
                final EditText name2 = view1.findViewById(R.id.title_loc);
                mBuilder.setView(view1);
                final AlertDialog dialog = mBuilder.create();
                dialog.show();
                final Places pl = new Places();
                bty.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!name1.getText().toString().isEmpty()||!name2.getText().toString().isEmpty()){
                        pl.name = name1.getText().toString();
                        pl.name2 = name2.getText().toString();
                        pl.latlng = latLng;
                        places.add(pl);
                        map.addMarker(new MarkerOptions().position(latLng).title(pl.getName2()));
                        map.moveCamera(CameraUpdateFactory.newLatLng(latLng));
                        adapter.notifyDataSetChanged();
                        DatabaseHelper db = new DatabaseHelper(getApplicationContext());
                        db.insertNote(pl);}
                        dialog.cancel();
                    }
                });
                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.cancel();
                    }
                });
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (i==1){
            lv.startAnimation(zoomin);
            relativeLayout.startAnimation(faded);
            r.startAnimation(faded);
            lv.setVisibility(View.VISIBLE);
            relativeLayout.setVisibility(View.GONE);
            r.setVisibility(View.GONE);
            i--;
        }
        else {
            relativeLayout.startAnimation(zoomin);
            r.startAnimation(zoomin);
            lv.startAnimation(faded);
            lv.setVisibility(View.GONE);
            relativeLayout.setVisibility(View.VISIBLE);
            r.setVisibility(View.VISIBLE);
            i++;
        }
        return super.onOptionsItemSelected(item);
            }
    public void radioClicked(View v){
        switch (v.getId()){
            case R.id.standard:
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                break;
            case R.id.satellite:
                map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                break;
            case R.id.hybrid:
                map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                break;
        }
    }
}
class DatabaseHelper extends SQLiteOpenHelper{
    public static final String DATABASE_NAME = "places.db";
    public static final String DATABASE_TABLE = "places";
    public static final String ID = "_id";
    public static final String PLACE_LOC = "_loc";
    public static final String PLACE_TITLE = "_title";
    public static final String LONGTITUDE = "_long";
    public static final String LANGTITUDE = "_lang";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + DATABASE_TABLE + "(" + ID + " integer primary key autoincrement, "+PLACE_LOC+" text not null, "+ PLACE_TITLE + " text not null, "+ LONGTITUDE + " double not null, "+LANGTITUDE + " double not null);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists "+DATABASE_TABLE);
        onCreate(db);
    }
    public void insertNote(Places place){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(PLACE_LOC,place.getName());
        cv.put(PLACE_TITLE,place.getName2());
        cv.put(LONGTITUDE,place.getLatlng().longitude);
        cv.put(LANGTITUDE,place.getLatlng().latitude);
        db.insert(DATABASE_TABLE,null,cv);

    }

    public ArrayList<Places> getNotes() {
        ArrayList<Places> places = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String get_places = "select * from "+DATABASE_TABLE;
        Cursor c = db.rawQuery(get_places,null);
        for (c.moveToFirst();!c.isAfterLast();c.moveToNext()){
            Places place = new Places();
            place.name = c.getString(c.getColumnIndex(PLACE_LOC));
            place.name2 = c.getString(c.getColumnIndex(PLACE_TITLE));
            place.latlng = new LatLng(c.getDouble(c.getColumnIndex(LANGTITUDE)),c.getDouble(c.getColumnIndex(LONGTITUDE)));
            places.add(place);
        }
        return places;
    }
}