package com.example.rauan1.googlemap;

import com.google.android.gms.maps.model.LatLng;

public class Places {
    String name;
    String name2;
    LatLng latlng;

    public LatLng getLatlng() {
        return latlng;
    }

    public String getName() {
        return name;
    }

    public String getName2() {
        return name2;
    }
}
