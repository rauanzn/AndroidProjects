package com.example.rauan1.mystat;

public class rest {
    public String getName() {
        return name;
    }

    public String getDay() {
        return day;
    }

    public int getMinutes() {
        return minutes;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setMinutes(int minutes) {
        this.minutes = minutes;
    }

    public String name;
    public String day;
    public int minutes;
}
